import numpy as np
from .mesh import build_uniform_mesh
from .assembly import build_pile_stiffness, residual_and_jacobian

def solve_newton(model):
    z_nodes, z_mid, lengths = build_uniform_mesh(model.pile.L, model.analysis.n_elem)
    K_pile = build_pile_stiffness(model, lengths)
    if model.analysis.regularization > 0:
        K_pile = K_pile + model.analysis.regularization * np.eye(K_pile.shape[0])

    n_nodes = len(z_nodes)
    w = np.full(n_nodes, model.analysis.initial_w, dtype=float)

    warnings, errors = [], []
    converged = False
    max_abs_dw = None
    max_abs_residual = None
    element_data = []
    tip_data = {"z_tip": float(model.pile.L), "w_tip": 0.0, "Qb": 0.0, "Qult": 0.0, "Qb_over_Qult": 0.0, "qz_model": model.qz_model["name"]}
    iteration = 0

    for iteration in range(1, model.analysis.max_iter + 1):
        R, J, element_data, tip_data, provisional_warnings = residual_and_jacobian(model, z_nodes, z_mid, lengths, K_pile, w)
        warnings.extend(provisional_warnings)
        max_abs_residual = float(np.max(np.abs(R))) if len(R) else 0.0
        try:
            dw = np.linalg.solve(J, -R)
        except np.linalg.LinAlgError as exc:
            errors.append(f"Linear solve failed: {exc}")
            break

        trial = np.maximum(w + dw, 0.0)
        actual_dw = trial - w
        w = trial
        max_abs_dw = float(np.max(np.abs(actual_dw))) if len(actual_dw) else 0.0

        R2, _, element_data, tip_data, provisional_warnings = residual_and_jacobian(model, z_nodes, z_mid, lengths, K_pile, w)
        warnings.extend(provisional_warnings)
        max_abs_residual = float(np.max(np.abs(R2))) if len(R2) else 0.0

        if max_abs_dw < model.analysis.tol_disp and max_abs_residual < model.analysis.tol_residual:
            converged = True
            break

    if not converged and not errors:
        warnings.append("Solver reached max_iter without convergence.")

    EA = model.pile.E * (np.pi * model.pile.D**2 / 4.0)
    N_elem = []
    for i, Le in enumerate(lengths):
        N_e = -EA * (w[i + 1] - w[i]) / Le
        N_elem.append(float(N_e))
    N_nodes = []
    if N_elem:
        for i in range(n_nodes):
            if i == 0:
                N_nodes.append(float(N_elem[0]))
            elif i == n_nodes - 1:
                N_nodes.append(float(N_elem[-1]))
            else:
                N_nodes.append(float(0.5 * (N_elem[i - 1] + N_elem[i])))
    else:
        N_nodes = [0.0] * n_nodes

    return {
        "ok": bool(converged and not errors),
        "converged": bool(converged),
        "iterations": int(iteration),
        "max_abs_dw": max_abs_dw,
        "max_abs_residual": max_abs_residual,
        "warnings": list(dict.fromkeys(warnings)),
        "errors": errors,
        "z_nodes": [float(v) for v in z_nodes.tolist()],
        "w": [float(v) for v in w.tolist()],
        "N_nodes": [float(v) for v in N_nodes],
        "element_data": element_data,
        "tip_data": tip_data,
    }
