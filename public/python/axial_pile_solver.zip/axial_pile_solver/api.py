from .validation import validate_input_dict
from .capacity import run_capacity_check
from .solver_core import solve_newton
from .results import build_results, build_summary
from .plotting import results_to_svgs

def solve_from_dict(data: dict) -> dict:
    model = validate_input_dict(data)
    capacity = run_capacity_check(model)
    if capacity["status"] == "abort" and not model.analysis.capacity_warning_only:
        return {
            "meta": {"units": model.units, "version": "0.4.1"},
            "results": {"nodes": {"z": [], "w": [], "N": []}, "elements": {}, "tip": {}},
            "summary": {},
            "capacity": capacity,
            "solver": {"ok": False, "converged": False, "iterations": 0, "max_abs_dw": None, "max_abs_residual": None, "warnings": capacity["warnings"], "errors": ["Aborted by capacity policy."]},
        }
    state = solve_newton(model)
    results = build_results(model, state)
    summary = build_summary(model, results)
    return {
        "meta": {"units": model.units, "version": "0.4.1"},
        "results": results,
        "summary": summary,
        "capacity": capacity,
        "solver": {
            "ok": bool(state["ok"]),
            "converged": bool(state["converged"]),
            "iterations": int(state["iterations"]),
            "max_abs_dw": state["max_abs_dw"],
            "max_abs_residual": state["max_abs_residual"],
            "warnings": list(dict.fromkeys(capacity["warnings"] + state["warnings"])),
            "errors": state["errors"],
        },
    }
