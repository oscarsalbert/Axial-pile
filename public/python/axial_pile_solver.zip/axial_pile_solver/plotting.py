from __future__ import annotations
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def _make_svg_plot(x, y, xlabel, ylabel, title, note=None):
    fig, ax = plt.subplots(figsize=(6.0, 7.0))
    if x is not None and y is not None and len(x) and len(y):
        ax.plot(x, y)
        ax.invert_yaxis()
    else:
        ax.text(0.5, 0.5, "No data available", ha="center", va="center", transform=ax.transAxes)
        ax.invert_yaxis()
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True)
    if note:
        fig.text(0.02, 0.01, note, fontsize=9)
    buf = io.StringIO()
    fig.tight_layout(rect=(0, 0.03 if note else 0, 1, 1))
    fig.savefig(buf, format="svg")
    plt.close(fig)
    return buf.getvalue()

def results_to_svgs(result: dict) -> dict[str, str]:
    nodes = result.get("results", {}).get("nodes", {})
    elements = result.get("results", {}).get("elements", {})
    tip = result.get("results", {}).get("tip", {})
    qb = tip.get("Qb")
    qb_rel = tip.get("Qb_over_Qult")
    qult = tip.get("Qult")
    return {
        "pile_displacement": _make_svg_plot(
            [1000.0 * v for v in nodes.get("w", [])], nodes.get("z", []),
            "Pile displacement (mm)", "z (m)", "Pile displacement (mm) vs z"
        ),
        "pile_axial_forces": _make_svg_plot(
            nodes.get("N", []), nodes.get("z", []),
            "Pile axial forces (kN)", "z (m)", "Pile axial forces (kN) vs z"
        ),
        "mobilised_shaft_resistance": _make_svg_plot(
            elements.get("t", []), elements.get("z_mid", []),
            "Mobilised shaft resistance (kPa)", "z (m)", "Mobilised shaft resistance (kPa) vs z",
            note=f"Mobilised base resistance Qb = {qb:.3f} kN" if qb is not None else "Mobilised base resistance Qb = n/a"
        ),
        "relative_shaft_resistance": _make_svg_plot(
            elements.get("t_over_tult", []), elements.get("z_mid", []),
            "Relative shaft resistance (-)", "z (m)", "Relative shaft resistance vs z",
            note=f"Relative base resistance Qb / Qult = {qb_rel:.5f}" if qb_rel is not None else "Relative base resistance Qb / Qult = n/a"
        ),
        "ultimate_shaft_resistance": _make_svg_plot(
            elements.get("tult", []), elements.get("z_mid", []),
            "Ultimate shaft resistance (kPa)", "z (m)", "Ultimate shaft resistance vs z",
            note=f"Ultimate base resistance Qult = {qult:.3f} kN" if qult is not None else "Ultimate base resistance Qult = n/a"
        ),
    }
