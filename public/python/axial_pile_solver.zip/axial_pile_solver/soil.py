from __future__ import annotations
import math
from .exceptions import ValidationError
from .types import TZContext, QZContext

def layer_at_depth(layers, z: float):
    last = layers[-1]
    for layer in layers:
        if layer is last:
            if layer.z_top <= z <= layer.z_bot:
                return layer
        else:
            if layer.z_top <= z < layer.z_bot:
                return layer
    raise ValidationError(f"No layer found at z={z}")

def total_stress_at_depth(model, z: float) -> float:
    total = 0.0
    for layer in model.layers:
        seg_top = layer.z_top
        seg_bot = min(layer.z_bot, z)
        if seg_bot <= seg_top:
            continue
        if seg_bot <= model.water.gwl_z:
            total += (seg_bot - seg_top) * layer.gamma_unsat
        elif seg_top >= model.water.gwl_z:
            total += (seg_bot - seg_top) * layer.gamma_sat
        else:
            total += (model.water.gwl_z - seg_top) * layer.gamma_unsat
            total += (seg_bot - model.water.gwl_z) * layer.gamma_sat
    return total

def pore_pressure_at_depth(model, z: float) -> float:
    return model.water.gamma_w * max(0.0, z - model.water.gwl_z)

def effective_stress_at_depth(model, z: float) -> float:
    return total_stress_at_depth(model, z) - pore_pressure_at_depth(model, z)

def build_tz_context_at_depth(model, z: float) -> TZContext:
    layer = layer_at_depth(model.layers, z)
    return TZContext(
        z=z,
        sigma_v0=total_stress_at_depth(model, z),
        u=pore_pressure_at_depth(model, z),
        sigma_v_eff=effective_stress_at_depth(model, z),
        D=model.pile.D,
        perimeter=math.pi * model.pile.D,
        pile_type=model.pile.type,
        layer_name=layer.name,
        params=layer.tz_params,
    )

def build_qz_context_at_tip(model) -> QZContext:
    z_tip = model.pile.L
    return QZContext(
        z_tip=z_tip,
        sigma_v0_tip=total_stress_at_depth(model, z_tip),
        u_tip=pore_pressure_at_depth(model, z_tip),
        sigma_v_eff_tip=effective_stress_at_depth(model, z_tip),
        D=model.pile.D,
        area_base=math.pi * model.pile.D**2 / 4.0,
        pile_type=model.pile.type,
        params=model.qz_model["params"],
    )
