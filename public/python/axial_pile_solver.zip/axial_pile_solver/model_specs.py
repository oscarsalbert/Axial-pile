TZ_MODEL_REQUIRED_PARAMS = {
    "API_CLAY": ["su"],
    "API_SAND": ["phi_deg", "delta_phi_ratio"],
    "REESE_ONEILL_CLAY": ["su"],
    "REESE_ONEILL_SAND": ["phi_deg", "delta_phi_ratio", "K"],
    "ONEILL_HASSAN_ROCK": ["UCS"],
}

QZ_MODEL_TIP_REQUIREMENTS = {
    "API_QZ_CLAY": ["su"],
    "API_QZ_SAND": ["phi_deg"],
    "REESE_ONEILL_QZ_CLAY": ["su"],
    "REESE_ONEILL_QZ_SAND": ["phi_deg"],
    "ROCK_QZ_SIMPLE": ["UCS"],
}

PROFILE_OR_SCALAR_ALLOWED = {
    "su", "alpha_override", "phi_deg", "delta_phi_ratio", "K", "UCS", "Em",
    "Nc_override", "Nq_override", "residual_factor", "K_override",
    "em_factor", "rock_shaft_factor", "rock_base_factor", "Qult_override", "tult_override",
}
