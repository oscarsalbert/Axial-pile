import numpy as np

def build_uniform_mesh(length: float, n_elem: int):
    z_nodes = np.linspace(0.0, length, n_elem + 1, dtype=float)
    z_mid = 0.5 * (z_nodes[:-1] + z_nodes[1:])
    lengths = z_nodes[1:] - z_nodes[:-1]
    return z_nodes, z_mid, lengths
