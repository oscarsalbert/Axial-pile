def build_results(model, state):
    z = state.get("z_nodes", [])
    w = state.get("w", [0.0] * len(z))
    N = state.get("N_nodes", [0.0] * len(z))
    elem = state.get("element_data", [])
    tip = state.get("tip_data", {"z_tip": model.pile.L, "w_tip": 0.0, "Qb": 0.0, "Qult": 0.0, "Qb_over_Qult": 0.0, "qz_model": model.qz_model["name"]})

    return {
        "nodes": {"z": z, "w": w, "N": N},
        "elements": {
            "z_mid": [e["z_mid"] for e in elem],
            "w_mid": [e["w_mid"] for e in elem],
            "t": [e["t"] for e in elem],
            "t_over_tult": [e["t_over_tult"] for e in elem],
            "tult": [e["tult"] for e in elem],
            "Qs_elem": [e["Qs_elem"] for e in elem],
            "tz_model": [e["tz_model"] for e in elem],
            "layer_name": [e["layer_name"] for e in elem],
        },
        "tip": tip,
    }

def build_summary(model, results):
    Qs_total = float(sum(results["elements"]["Qs_elem"]))
    Qb = float(results["tip"]["Qb"])
    Q_total = Qs_total + Qb
    return {
        "P_head": float(model.load.P_head),
        "w_head": float(results["nodes"]["w"][0]) if results["nodes"]["w"] else 0.0,
        "w_tip": float(results["tip"]["w_tip"]),
        "N_head": float(results["nodes"]["N"][0]) if results["nodes"]["N"] else 0.0,
        "N_tip": float(results["nodes"]["N"][-1]) if results["nodes"]["N"] else 0.0,
        "Qs_total": Qs_total,
        "Qb": Qb,
        "Q_total": Q_total,
        "shaft_pct": 100.0 * Qs_total / Q_total if Q_total > 0 else 0.0,
        "base_pct": 100.0 * Qb / Q_total if Q_total > 0 else 0.0,
    }
