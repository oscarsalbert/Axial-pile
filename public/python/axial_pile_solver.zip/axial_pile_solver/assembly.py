from __future__ import annotations
import numpy as np

from .models import TZ_MODEL_REGISTRY, QZ_MODEL_REGISTRY
from .soil import build_tz_context_at_depth, build_qz_context_at_tip, layer_at_depth

def pile_area(D: float) -> float:
    return np.pi * D**2 / 4.0

def pile_perimeter(D: float) -> float:
    return np.pi * D

def build_pile_stiffness(model, lengths):
    n_nodes = len(lengths) + 1
    K = np.zeros((n_nodes, n_nodes), dtype=float)
    EA = model.pile.E * pile_area(model.pile.D)
    for e, Le in enumerate(lengths):
        ke = EA / Le * np.array([[1.0, -1.0], [-1.0, 1.0]], dtype=float)
        K[e:e+2, e:e+2] += ke
    return K

def residual_and_jacobian(model, z_nodes, z_mid, lengths, K_pile, w):
    n_nodes = len(z_nodes)
    R = K_pile @ w
    J = K_pile.copy()
    perim = pile_perimeter(model.pile.D)
    element_data = []
    provisional_warnings = []

    for e, (zm, Le) in enumerate(zip(z_mid, lengths)):
        i, j = e, e + 1
        wm = 0.5 * (w[i] + w[j])
        ctx = build_tz_context_at_depth(model, float(zm))
        layer = layer_at_depth(model.layers, float(zm))
        tz_model = TZ_MODEL_REGISTRY[layer.tz_model]
        resp = tz_model.response(model, ctx, float(max(wm, 0.0)))
        if resp.provisional_warnings:
            provisional_warnings.extend(resp.provisional_warnings)

        Fs = resp.t * perim * Le
        R[i] += 0.5 * Fs
        R[j] += 0.5 * Fs

        coeff = resp.dt_dw * perim * Le * 0.25
        J[i, i] += coeff
        J[i, j] += coeff
        J[j, i] += coeff
        J[j, j] += coeff

        element_data.append({
            "z_mid": float(zm),
            "w_mid": float(wm),
            "t": float(resp.t),
            "dt_dw": float(resp.dt_dw),
            "tult": float(resp.tult),
            "t_over_tult": float(resp.t / resp.tult) if resp.tult > 0 else 0.0,
            "Qs_elem": float(Fs),
            "tz_model": layer.tz_model,
            "layer_name": layer.name,
        })

    qctx = build_qz_context_at_tip(model)
    qz_model = QZ_MODEL_REGISTRY[model.qz_model["name"]]
    qresp = qz_model.response(model, qctx, float(max(w[-1], 0.0)))
    if qresp.provisional_warnings:
        provisional_warnings.extend(qresp.provisional_warnings)
    R[-1] += qresp.Qb
    J[-1, -1] += qresp.dQb_dw

    Fext = np.zeros(n_nodes, dtype=float)
    Fext[0] = model.load.P_head
    R = R - Fext

    tip_data = {
        "z_tip": float(model.pile.L),
        "w_tip": float(w[-1]),
        "Qb": float(qresp.Qb),
        "Qult": float(qresp.Qult),
        "Qb_over_Qult": float(qresp.Qb / qresp.Qult) if qresp.Qult > 0 else 0.0,
        "qz_model": model.qz_model["name"],
    }
    return R, J, element_data, tip_data, provisional_warnings
