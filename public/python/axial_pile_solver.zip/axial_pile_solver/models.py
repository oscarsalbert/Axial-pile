from __future__ import annotations
from dataclasses import dataclass
from math import exp, pi, radians, tan

from .constants import (
    API_CLAY_TZ_POINTS_TEMPLATE, API_QZ_POINTS, REESE_ONEILL_CLAY_TZ_POINTS,
    REESE_ONEILL_SAND_TZ_POINTS, REESE_ONEILL_CLAY_QZ_POINTS, REESE_ONEILL_SAND_QZ_POINTS,
    SIGMA_V_MIN_KPA
)
from .numeric import piecewise_linear_value_and_slope
from .profiles import get_param_value
from .soil import layer_at_depth

def alpha_api_clay(su: float, sigma_v_eff: float) -> float:
    sigma = max(sigma_v_eff, SIGMA_V_MIN_KPA)
    psi = su / sigma
    if psi <= 1.0:
        alpha = 0.5 * psi ** (-0.5)
    else:
        alpha = 0.5 * psi ** (-0.25)
    return min(alpha, 1.0)

def tan_delta_from_phi(phi_deg: float, delta_phi_ratio: float) -> float:
    return tan(radians(phi_deg * delta_phi_ratio))

def nq_from_phi_deg(phi_deg: float) -> float:
    phi = radians(phi_deg)
    return exp(pi * tan(phi)) * tan(pi / 4.0 + phi / 2.0) ** 2

@dataclass(frozen=True)
class TZResponse:
    t: float
    dt_dw: float
    tult: float
    provisional_warnings: list[str] | None = None

@dataclass(frozen=True)
class QZResponse:
    Qb: float
    dQb_dw: float
    Qult: float
    provisional_warnings: list[str] | None = None

@dataclass(frozen=True)
class APIClayTZ:
    name: str = "API_CLAY"
    def response(self, model, ctx, w: float) -> TZResponse:
        layer = layer_at_depth(model.layers, ctx.z)
        su = get_param_value(ctx.params, "su", ctx.z, layer)
        alpha_override = get_param_value(ctx.params, "alpha_override", ctx.z, layer, default=None) if "alpha_override" in ctx.params else None
        residual_factor = float(ctx.params.get("residual_factor", 0.9))
        alpha = alpha_override if alpha_override is not None else alpha_api_clay(su, ctx.sigma_v_eff)
        tult = alpha * su
        z_peak = max(0.02 * ctx.D, 1e-12)
        points = [(x, residual_factor if y is None else y) for x, y in API_CLAY_TZ_POINTS_TEMPLATE]
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, points)
            return TZResponse(0.0, max(dm_dr * tult / z_peak, 1e-12), tult, [])
        r = w / z_peak
        m, dm_dr = piecewise_linear_value_and_slope(r, points)
        return TZResponse(m * tult, max(dm_dr * tult / z_peak, 1e-12), tult, [])

@dataclass(frozen=True)
class APISandTZ:
    name: str = "API_SAND"
    def response(self, model, ctx, w: float) -> TZResponse:
        layer = layer_at_depth(model.layers, ctx.z)
        phi_deg = get_param_value(ctx.params, "phi_deg", ctx.z, layer)
        delta_phi_ratio = get_param_value(ctx.params, "delta_phi_ratio", ctx.z, layer)
        provisional = []
        if "K_override" in ctx.params:
            K = float(ctx.params["K_override"])
        else:
            K = 1.0 if model.pile.type == "DRIVEN" else 0.7
            provisional.append(f"API_SAND at z={ctx.z:.3f} m used provisional default K_override={K}.")
        tan_delta = tan_delta_from_phi(phi_deg, delta_phi_ratio)
        tult = K * tan_delta * max(ctx.sigma_v_eff, 0.0)
        w_peak = 0.00254
        if w <= 0.0:
            return TZResponse(0.0, max(tult / max(w_peak, 1e-12), 1e-12), tult, provisional)
        if w < w_peak:
            return TZResponse(tult * w / w_peak, max(tult / w_peak, 1e-12), tult, provisional)
        return TZResponse(tult, 1e-12, tult, provisional)

@dataclass(frozen=True)
class ReeseOneillClayTZ:
    name: str = "REESE_ONEILL_CLAY"
    def response(self, model, ctx, w: float) -> TZResponse:
        layer = layer_at_depth(model.layers, ctx.z)
        su = get_param_value(ctx.params, "su", ctx.z, layer)
        alpha_override = get_param_value(ctx.params, "alpha_override", ctx.z, layer, default=None) if "alpha_override" in ctx.params else None
        alpha = alpha_override if alpha_override is not None else alpha_api_clay(su, ctx.sigma_v_eff)
        tult = alpha * su
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, REESE_ONEILL_CLAY_TZ_POINTS)
            return TZResponse(0.0, max(dm_dr * tult / max(ctx.D, 1e-12), 1e-12), tult, [])
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, REESE_ONEILL_CLAY_TZ_POINTS)
        return TZResponse(m * tult, max(dm_dr * tult / max(ctx.D, 1e-12), 1e-12), tult, [])

@dataclass(frozen=True)
class ReeseOneillSandTZ:
    name: str = "REESE_ONEILL_SAND"
    def response(self, model, ctx, w: float) -> TZResponse:
        layer = layer_at_depth(model.layers, ctx.z)
        phi_deg = get_param_value(ctx.params, "phi_deg", ctx.z, layer)
        delta_phi_ratio = get_param_value(ctx.params, "delta_phi_ratio", ctx.z, layer)
        K = get_param_value(ctx.params, "K", ctx.z, layer)
        tan_delta = tan_delta_from_phi(phi_deg, delta_phi_ratio)
        tult = K * tan_delta * max(ctx.sigma_v_eff, 0.0)
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, REESE_ONEILL_SAND_TZ_POINTS)
            return TZResponse(0.0, max(dm_dr * tult / max(ctx.D, 1e-12), 1e-12), tult, [])
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, REESE_ONEILL_SAND_TZ_POINTS)
        return TZResponse(m * tult, max(dm_dr * tult / max(ctx.D, 1e-12), 1e-12), tult, [])

@dataclass(frozen=True)
class ONeillHassanRockTZ:
    name: str = "ONEILL_HASSAN_ROCK"
    def response(self, model, ctx, w: float) -> TZResponse:
        layer = layer_at_depth(model.layers, ctx.z)
        ucs = get_param_value(ctx.params, "UCS", ctx.z, layer)
        provisional = []
        em_factor = float(ctx.params.get("em_factor", 200.0))
        rock_shaft_factor = float(ctx.params.get("rock_shaft_factor", 0.10))
        if "Em" in ctx.params:
            Em = get_param_value(ctx.params, "Em", ctx.z, layer)
        else:
            Em = em_factor * ucs
            provisional.append(f"ONEILL_HASSAN_ROCK at z={ctx.z:.3f} m used provisional default Em={Em}.")
        if "tult_override" in ctx.params:
            tult = get_param_value(ctx.params, "tult_override", ctx.z, layer)
        else:
            tult = rock_shaft_factor * ucs
            provisional.append(f"ONEILL_HASSAN_ROCK at z={ctx.z:.3f} m used provisional default tult={tult}.")
        a = max(2.5 * ctx.D / max(Em, 1e-12), 1e-12)
        b = 1.0 / max(tult, 1e-12)
        if w <= 0.0:
            return TZResponse(0.0, max(1.0 / a, 1e-12), tult, provisional)
        denom = a + b * w
        t = w / denom
        dt_dw = a / (denom * denom)
        return TZResponse(t, max(dt_dw, 1e-12), tult, provisional)

@dataclass(frozen=True)
class APIClayQZ:
    name: str = "API_QZ_CLAY"
    def response(self, model, ctx, w: float) -> QZResponse:
        tip_layer = layer_at_depth(model.layers, ctx.z_tip)
        su_tip = get_param_value(tip_layer.tz_params, "su", ctx.z_tip, tip_layer)
        Nc = float(ctx.params.get("Nc_override", 9.0))
        Qult = Nc * su_tip * ctx.area_base
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, API_QZ_POINTS)
            return QZResponse(0.0, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, [])
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, API_QZ_POINTS)
        return QZResponse(m * Qult, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, [])

@dataclass(frozen=True)
class APISandQZ:
    name: str = "API_QZ_SAND"
    def response(self, model, ctx, w: float) -> QZResponse:
        tip_layer = layer_at_depth(model.layers, ctx.z_tip)
        phi_tip = get_param_value(tip_layer.tz_params, "phi_deg", ctx.z_tip, tip_layer)
        provisional = []
        if "Nq_override" in ctx.params:
            Nq = float(ctx.params["Nq_override"])
        else:
            Nq = nq_from_phi_deg(phi_tip)
            provisional.append(f"API_QZ_SAND at tip used automatic Nq={Nq:.6f}.")
        Qult = max(ctx.sigma_v_eff_tip, 0.0) * Nq * ctx.area_base
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, API_QZ_POINTS)
            return QZResponse(0.0, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, provisional)
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, API_QZ_POINTS)
        return QZResponse(m * Qult, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, provisional)

@dataclass(frozen=True)
class ReeseOneillClayQZ:
    name: str = "REESE_ONEILL_QZ_CLAY"
    def response(self, model, ctx, w: float) -> QZResponse:
        tip_layer = layer_at_depth(model.layers, ctx.z_tip)
        su_tip = get_param_value(tip_layer.tz_params, "su", ctx.z_tip, tip_layer)
        Nc = float(ctx.params.get("Nc_override", 9.0))
        Qult = Nc * su_tip * ctx.area_base
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, REESE_ONEILL_CLAY_QZ_POINTS)
            return QZResponse(0.0, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, [])
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, REESE_ONEILL_CLAY_QZ_POINTS)
        return QZResponse(m * Qult, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, [])

@dataclass(frozen=True)
class ReeseOneillSandQZ:
    name: str = "REESE_ONEILL_QZ_SAND"
    def response(self, model, ctx, w: float) -> QZResponse:
        tip_layer = layer_at_depth(model.layers, ctx.z_tip)
        phi_tip = get_param_value(tip_layer.tz_params, "phi_deg", ctx.z_tip, tip_layer)
        provisional = []
        if "Nq_override" in ctx.params:
            Nq = float(ctx.params["Nq_override"])
        else:
            Nq = nq_from_phi_deg(phi_tip)
            provisional.append(f"REESE_ONEILL_QZ_SAND at tip used automatic Nq={Nq:.6f}.")
        Qult = max(ctx.sigma_v_eff_tip, 0.0) * Nq * ctx.area_base
        if w <= 0.0:
            _, dm_dr = piecewise_linear_value_and_slope(0.0, REESE_ONEILL_SAND_QZ_POINTS)
            return QZResponse(0.0, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, provisional)
        r = w / max(ctx.D, 1e-12)
        m, dm_dr = piecewise_linear_value_and_slope(r, REESE_ONEILL_SAND_QZ_POINTS)
        return QZResponse(m * Qult, max(dm_dr * Qult / max(ctx.D, 1e-12), 1e-12), Qult, provisional)

@dataclass(frozen=True)
class RockQZSimple:
    name: str = "ROCK_QZ_SIMPLE"
    def response(self, model, ctx, w: float) -> QZResponse:
        tip_layer = layer_at_depth(model.layers, ctx.z_tip)
        ucs = get_param_value(tip_layer.tz_params, "UCS", ctx.z_tip, tip_layer)
        provisional = []
        em_factor = float(ctx.params.get("em_factor", 200.0))
        rock_base_factor = float(ctx.params.get("rock_base_factor", 5.0))
        if "Em" in tip_layer.tz_params:
            Em = get_param_value(tip_layer.tz_params, "Em", ctx.z_tip, tip_layer)
        else:
            Em = em_factor * ucs
            provisional.append(f"ROCK_QZ_SIMPLE at tip used provisional default Em={Em}.")
        if "Qult_override" in ctx.params:
            Qult = float(ctx.params["Qult_override"])
        else:
            Qult = rock_base_factor * ucs * ctx.area_base
            provisional.append(f"ROCK_QZ_SIMPLE at tip used provisional default Qult={Qult}.")
        a = Qult / max(ctx.area_base * Em / max(ctx.D, 1e-12), 1e-12)
        b = 1.0 / max(Qult, 1e-12)
        if w <= 0.0:
            return QZResponse(0.0, max(1.0 / a, 1e-12), Qult, provisional)
        denom = a + b * w
        Qb = w / denom
        dQb_dw = a / (denom * denom)
        return QZResponse(Qb, max(dQb_dw, 1e-12), Qult, provisional)

TZ_MODEL_REGISTRY = {
    "API_CLAY": APIClayTZ(),
    "API_SAND": APISandTZ(),
    "REESE_ONEILL_CLAY": ReeseOneillClayTZ(),
    "REESE_ONEILL_SAND": ReeseOneillSandTZ(),
    "ONEILL_HASSAN_ROCK": ONeillHassanRockTZ(),
}

QZ_MODEL_REGISTRY = {
    "API_QZ_CLAY": APIClayQZ(),
    "API_QZ_SAND": APISandQZ(),
    "REESE_ONEILL_QZ_CLAY": ReeseOneillClayQZ(),
    "REESE_ONEILL_QZ_SAND": ReeseOneillSandQZ(),
    "ROCK_QZ_SIMPLE": RockQZSimple(),
}
