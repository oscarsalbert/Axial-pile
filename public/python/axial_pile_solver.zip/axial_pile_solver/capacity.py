from .mesh import build_uniform_mesh
from .models import TZ_MODEL_REGISTRY, QZ_MODEL_REGISTRY
from .soil import build_tz_context_at_depth, build_qz_context_at_tip, layer_at_depth

def run_capacity_check(model):
    z_nodes, z_mid, lengths = build_uniform_mesh(model.pile.L, model.analysis.n_elem)
    perim = 3.141592653589793 * model.pile.D
    Qs_peak = 0.0
    warnings = []
    for z, Le in zip(z_mid, lengths):
        ctx = build_tz_context_at_depth(model, float(z))
        layer = layer_at_depth(model.layers, float(z))
        tz_model = TZ_MODEL_REGISTRY[layer.tz_model]
        resp = tz_model.response(model, ctx, 1e9)
        if resp.provisional_warnings:
            warnings.extend(resp.provisional_warnings)
        Qs_peak += resp.tult * perim * Le
    qctx = build_qz_context_at_tip(model)
    qresp = QZ_MODEL_REGISTRY[model.qz_model["name"]].response(model, qctx, 1e9)
    if qresp.provisional_warnings:
        warnings.extend(qresp.provisional_warnings)
    Qb_peak = qresp.Qult
    Q_total_peak = Qs_peak + Qb_peak
    status = "ok"
    if model.load.P_head > Q_total_peak:
        warnings.append("Head load exceeds estimated peak capacity.")
        status = "warning" if model.analysis.capacity_warning_only else "abort"
    return {
        "Qs_peak": float(Qs_peak),
        "Qb_peak": float(Qb_peak),
        "Q_total_peak": float(Q_total_peak),
        "warnings": list(dict.fromkeys(warnings)),
        "status": status,
        "warning_only": bool(model.analysis.capacity_warning_only),
    }
