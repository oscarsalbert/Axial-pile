from __future__ import annotations

import numpy as np

from .models import TZ_MODEL_REGISTRY, QZ_MODEL_REGISTRY
from .soil import build_tz_context_at_depth, build_qz_context_at_tip, layer_at_depth


def _interp_w_at_depth(z: float, z_nodes: list[float], w_nodes: list[float]) -> float:
    if not z_nodes or not w_nodes or len(z_nodes) != len(w_nodes):
        return 0.0

    if z <= z_nodes[0]:
        return float(w_nodes[0])

    if z >= z_nodes[-1]:
        return float(w_nodes[-1])

    for i in range(len(z_nodes) - 1):
        z1 = float(z_nodes[i])
        z2 = float(z_nodes[i + 1])

        if z1 <= z <= z2:
            w1 = float(w_nodes[i])
            w2 = float(w_nodes[i + 1])

            if abs(z2 - z1) < 1e-12:
                return w1

            ratio = (z - z1) / (z2 - z1)
            return w1 + ratio * (w2 - w1)

    return float(w_nodes[-1])


def build_tz_curves(model, state, tz_depths, n_points=60, w_max_m=0.03):
    z_nodes = state.get("z_nodes", [])
    w_nodes = state.get("w", [])

    curves = []

    for z in tz_depths:
        z = float(z)

        layer = layer_at_depth(model.layers, z)
        ctx = build_tz_context_at_depth(model, z)
        tz_model = TZ_MODEL_REGISTRY[layer.tz_model]

        w_values = np.linspace(0.0, float(w_max_m), int(n_points))
        t_values = []
        warnings = []

        for w in w_values:
            resp = tz_model.response(model, ctx, float(w))
            t_values.append(float(resp.t))
            if resp.provisional_warnings:
                warnings.extend(resp.provisional_warnings)

        w_mobilized = _interp_w_at_depth(z, z_nodes, w_nodes)
        resp_mobilized = tz_model.response(model, ctx, float(w_mobilized))

        curves.append({
            "z": float(z),
            "layer_name": layer.name,
            "tz_model": layer.tz_model,
            "w": [float(v) for v in w_values.tolist()],
            "t": t_values,
            "w_mobilized": float(w_mobilized),
            "t_mobilized": float(resp_mobilized.t),
            "tult": float(resp_mobilized.tult),
            "warnings": list(dict.fromkeys(warnings)),
        })

    return curves


def build_qz_curve(model, state, n_points=60, w_max_m=0.03):
    ctx = build_qz_context_at_tip(model)
    qz_model = QZ_MODEL_REGISTRY[model.qz_model["name"]]

    w_values = np.linspace(0.0, float(w_max_m), int(n_points))
    q_values = []
    warnings = []

    for w in w_values:
        resp = qz_model.response(model, ctx, float(w))
        q_values.append(float(resp.Qb))
        if resp.provisional_warnings:
            warnings.extend(resp.provisional_warnings)

    w_tip = float(state.get("tip_data", {}).get("w_tip", 0.0))
    resp_mobilized = qz_model.response(model, ctx, float(w_tip))

    return {
        "z_tip": float(model.pile.L),
        "qz_model": model.qz_model["name"],
        "w": [float(v) for v in w_values.tolist()],
        "Q": q_values,
        "w_mobilized": float(w_tip),
        "Q_mobilized": float(resp_mobilized.Qb),
        "Qult": float(resp_mobilized.Qult),
        "warnings": list(dict.fromkeys(warnings)),
    }


def build_requested_curves(model, state, curve_requests: dict | None):
    if not curve_requests:
        return {}

    tz_depths = curve_requests.get("tz_depths", []) or []
    include_qz = bool(curve_requests.get("include_qz", True))
    n_points = int(curve_requests.get("n_points", 60))
    w_max_m = float(curve_requests.get("w_max_m", 0.03))
    qz_w_max_m = float(curve_requests.get("qz_w_max_m", w_max_m))

    output = {}

    if tz_depths:
        output["tz"] = build_tz_curves(
            model=model,
            state=state,
            tz_depths=tz_depths,
            n_points=n_points,
            w_max_m=w_max_m,
        )

    if include_qz:
        output["qz"] = build_qz_curve(
            model=model,
            state=state,
            n_points=n_points,
            w_max_m=qz_w_max_m,
        )

    return output
