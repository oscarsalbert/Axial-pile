class SolverError(Exception):
    pass

class ValidationError(SolverError):
    pass

class ModelError(SolverError):
    pass
