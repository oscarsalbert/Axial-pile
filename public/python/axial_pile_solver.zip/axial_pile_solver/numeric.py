def piecewise_linear_value_and_slope(x: float, points):
    if len(points) < 2:
        raise ValueError("At least two points are required.")
    if x <= points[0][0]:
        xa, ya = points[0]
        xb, yb = points[1]
        m = (yb - ya) / (xb - xa)
        return ya, m
    for i in range(len(points) - 1):
        xa, ya = points[i]
        xb, yb = points[i + 1]
        if xa <= x <= xb:
            m = (yb - ya) / (xb - xa)
            y = ya + m * (x - xa)
            return y, m
    return points[-1][1], 0.0
