from .exceptions import ValidationError

def eval_profile(profile: dict, z: float, layer, name: str) -> float:
    ptype = profile.get("type")
    if ptype == "const":
        return float(profile["value"])
    if ptype == "linear_layer":
        dz = layer.z_bot - layer.z_top
        if dz <= 0:
            raise ValidationError(f"Layer '{layer.name}' invalid while evaluating '{name}'.")
        top = float(profile["top"])
        bot = float(profile["bot"])
        ratio = (z - layer.z_top) / dz
        ratio = min(max(ratio, 0.0), 1.0)
        return top + (bot - top) * ratio
    raise ValidationError(f"Invalid profile type for parameter '{name}'.")

def get_param_value(params: dict, name: str, z: float, layer, default=None):
    if name not in params:
        if default is None:
            raise ValidationError(f"Missing required parameter '{name}' in layer '{layer.name}'.")
        return default
    value = params[name]
    if isinstance(value, dict) and "type" in value:
        return eval_profile(value, z, layer, name)
    return float(value)
