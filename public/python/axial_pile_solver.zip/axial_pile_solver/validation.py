from .constants import UNITS
from .exceptions import ValidationError
from .models import TZ_MODEL_REGISTRY, QZ_MODEL_REGISTRY
from .model_specs import TZ_MODEL_REQUIRED_PARAMS, QZ_MODEL_TIP_REQUIREMENTS
from .types import Analysis, Load, ModelInput, Layer, Pile, Water

def _validate_profile(v, name):
    if not isinstance(v, dict):
        raise ValidationError(f"Profile '{name}' must be dict.")
    t = v.get("type")
    if t == "const":
        if "value" not in v:
            raise ValidationError(f"Profile '{name}' missing value.")
    elif t == "linear_layer":
        if "top" not in v or "bot" not in v:
            raise ValidationError(f"Profile '{name}' missing top/bot.")
    else:
        raise ValidationError(f"Profile '{name}' has invalid type '{t}'.")

def _validate_non_negative_or_positive(name: str, value):
    v = float(value)
    if name in {"su", "phi_deg", "UCS", "Em", "K", "Nc_override", "Nq_override", "K_override", "tult_override", "Qult_override"} and v <= 0:
        raise ValidationError(f"Parameter '{name}' must be > 0.")
    if name in {"residual_factor", "delta_phi_ratio", "rock_shaft_factor", "rock_base_factor", "em_factor"} and v < 0:
        raise ValidationError(f"Parameter '{name}' must be >= 0.")
    if name == "residual_factor" and not (0.0 <= v <= 1.0):
        raise ValidationError("residual_factor must be between 0 and 1.")
    if name == "delta_phi_ratio" and v == 0:
        raise ValidationError("delta_phi_ratio must be > 0.")
    if name == "phi_deg" and not (0.0 < v < 90.0):
        raise ValidationError("phi_deg must be between 0 and 90.")
    if name == "alpha_override" and not (0.0 < v <= 1.0):
        raise ValidationError("alpha_override must be in (0, 1].")

def _validate_param_value(name: str, value):
    if isinstance(value, dict) and "type" in value:
        _validate_profile(value, name)
        if value["type"] == "const":
            _validate_non_negative_or_positive(name.split(".")[-1], value["value"])
        elif value["type"] == "linear_layer":
            _validate_non_negative_or_positive(name.split(".")[-1], value["top"])
            _validate_non_negative_or_positive(name.split(".")[-1], value["bot"])
    else:
        _validate_non_negative_or_positive(name.split(".")[-1], value)

def validate_input_dict(data: dict) -> ModelInput:
    if not isinstance(data, dict):
        raise ValidationError("Input must be a dict.")
    for key in ("units", "pile", "water", "analysis", "load", "qz_model", "layers"):
        if key not in data:
            raise ValidationError(f"Missing required key '{key}'.")
    if data["units"] != UNITS:
        raise ValidationError(f"Units must be '{UNITS}'.")

    p = data["pile"]
    pile = Pile(L=float(p["L"]), D=float(p["D"]), E=float(p["E"]), type=str(p["type"]).upper(), base=str(p["base"]).upper())
    if pile.L <= 0 or pile.D <= 0 or pile.E <= 0:
        raise ValidationError("Pile L, D and E must be > 0.")

    w = data["water"]
    water = Water(gwl_z=float(w["gwl_z"]), gamma_w=float(w["gamma_w"]))
    if water.gamma_w <= 0:
        raise ValidationError("gamma_w must be > 0.")

    a = data["analysis"]
    analysis = Analysis(
        n_elem=int(a["n_elem"]),
        tol_disp=float(a["tol_disp"]),
        tol_residual=float(a.get("tol_residual", 1e-6)),
        max_iter=int(a["max_iter"]),
        regularization=float(a.get("regularization", 1e-9)),
        initial_w=float(a.get("initial_w", 1e-9)),
        capacity_warning_only=bool(a.get("capacity_warning_only", True)),
    )
    if analysis.n_elem < 1 or analysis.max_iter < 1:
        raise ValidationError("Invalid analysis values.")

    load = Load(P_head=float(data["load"]["P_head"]))
    if load.P_head < 0:
        raise ValidationError("Compression-only expects P_head >= 0.")

    qz = data["qz_model"]
    qz_name = str(qz["name"]).upper()
    if qz_name not in QZ_MODEL_REGISTRY:
        raise ValidationError(f"Unsupported q-z model '{qz_name}'.")

    layers = []
    prev_bot = None
    raw_layers = data["layers"]
    if not isinstance(raw_layers, list) or not raw_layers:
        raise ValidationError("layers must be non-empty list.")
    for idx, lr in enumerate(raw_layers):
        tz_name = str(lr["tz_model"]).upper()
        if tz_name not in TZ_MODEL_REGISTRY:
            raise ValidationError(f"Unsupported t-z model '{tz_name}'.")
        layer = Layer(
            name=str(lr["name"]),
            z_top=float(lr["z_top"]),
            z_bot=float(lr["z_bot"]),
            gamma_unsat=float(lr["gamma_unsat"]),
            gamma_sat=float(lr["gamma_sat"]),
            tz_model=tz_name,
            tz_params=dict(lr["tz_params"]),
        )
        if layer.z_top < 0 or layer.z_bot <= layer.z_top:
            raise ValidationError(f"Layer '{layer.name}' invalid depth range.")
        if prev_bot is not None and abs(layer.z_top - prev_bot) > 1e-9:
            raise ValidationError("Layers must be continuous without gaps/overlaps.")
        prev_bot = layer.z_bot
        for required in TZ_MODEL_REQUIRED_PARAMS[tz_name]:
            if required not in layer.tz_params:
                raise ValidationError(f"Layer '{layer.name}' using model '{tz_name}' requires parameter '{required}'.")
        for pname, pval in layer.tz_params.items():
            _validate_param_value(f"{layer.name}.{pname}", pval)
        layers.append(layer)

    if layers[-1].z_bot < pile.L - 1e-9:
        raise ValidationError("Last layer must reach pile tip.")

    for tip_required in QZ_MODEL_TIP_REQUIREMENTS[qz_name]:
        if tip_required not in layers[-1].tz_params:
            raise ValidationError(f"Tip model '{qz_name}' requires '{tip_required}' to exist in the tip layer tz_params.")

    for pname, pval in qz["params"].items():
        _validate_param_value(f"qz_model.params.{pname}", pval)

    return ModelInput(
        units=UNITS,
        pile=pile,
        water=water,
        analysis=analysis,
        load=load,
        qz_model={"name": qz_name, "params": dict(qz["params"])},
        layers=layers,
    )
