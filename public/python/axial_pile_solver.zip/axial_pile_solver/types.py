from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class Pile:
    L: float
    D: float
    E: float
    type: str
    base: str

@dataclass(frozen=True)
class Water:
    gwl_z: float
    gamma_w: float

@dataclass(frozen=True)
class Analysis:
    n_elem: int
    tol_disp: float
    tol_residual: float
    max_iter: int
    regularization: float = 1e-9
    initial_w: float = 1e-9
    capacity_warning_only: bool = True

@dataclass(frozen=True)
class Load:
    P_head: float

@dataclass(frozen=True)
class Layer:
    name: str
    z_top: float
    z_bot: float
    gamma_unsat: float
    gamma_sat: float
    tz_model: str
    tz_params: dict[str, Any]

@dataclass(frozen=True)
class ModelInput:
    units: str
    pile: Pile
    water: Water
    analysis: Analysis
    load: Load
    qz_model: dict[str, Any]
    layers: list[Layer]

@dataclass(frozen=True)
class TZContext:
    z: float
    sigma_v0: float
    u: float
    sigma_v_eff: float
    D: float
    perimeter: float
    pile_type: str
    layer_name: str
    params: dict[str, Any]

@dataclass(frozen=True)
class QZContext:
    z_tip: float
    sigma_v0_tip: float
    u_tip: float
    sigma_v_eff_tip: float
    D: float
    area_base: float
    pile_type: str
    params: dict[str, Any]
